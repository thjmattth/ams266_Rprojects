#' AMSdata.
#'
#' @name AMSdata
#' @docType package
NULL
