#' election_2016
#'
#' The data on the proportion of each county that voted for a particular candidate.
#'
#' @format A data frame with 8 variables: \code{state}, \code{state_abbreviation},
#'    \code{county}, \code{fips}, \code{party}, \code{candidate}, \code{votes},
#'    and \code{fraction_votes}.
#' @source \url{https://www.kaggle.com/benhamner/2016-us-election/data}
"election_2016"

#' air_qual
#'
#' These data come from the Environmental Protection Agency.
#'    This set uses the median daily-level PM2.5 readings from
#'    142 outdoor air quality monitors around California in 2017.
#'
#' @format A data frame with 6 variables, \code{AQS_SITE_ID},
#'    \code{STATE}, \code{COUNTY}, \code{SITE_LATITUDE}, and
#'    \code{SITE_LONGITUDE}.
#' @source \url{https://www.epa.gov/outdoor-air-quality-data/download-daily-data}
"air_qual"

#' lesson_8
#'
#' These data contain the somewhat-cleaned text from the lesson 8 lecture
#'    slides from AMS 266A. All credit for the words goes to Abel Rodriguez.
#'
#' @format A data frame containing a single character vector, \code{hr}.
#'    Each element in the vector contains the text in a single slide.
"lesson_8"

#' new_quakes
#'
#' These data contain the information on earthquakes with magnitudes over 4.5 recorded between October 23, 2017 and November 23, 2017.
#'
#' @source \url{https://earthquake.usgs.gov/earthquakes/feed/v1.0/csv.php}
#' @format A data frame of 509 observations and 22 variables, including \code{longitude}, \code{latitude}, and \code{mag} (magnitude).
"new_quakes"
